﻿using System;
using System.Collections.Generic;
using System.Linq;
using PharmaAdminDomain.Enum;
using PharmaTech.PharmaAdmin.Domain.Model;

namespace PharmaTech.PharmaAdmin.Domain.Service
{
    public class MedicamentoService
    {
        private List<Medicamento> medicamentos;

        public MedicamentoService()
        {
            medicamentos = new List<Medicamento>();
        }

        public long CadastrarMedicamento(string nome, double preco, TipoMedicamento tipo)
        {
            long codigo = medicamentos.Count + 1;

            if (medicamentos.Any(m => m.Codigo == codigo || m.Nome == nome))
            {
                 Console.WriteLine("Já existe um medicamento cadastrado com o mesmo código ou nome");
            }

            var medicamento = new Medicamento
            {
                Codigo = codigo,
                Nome = nome,
                Preco = preco,
                Tipo = tipo
            };

            medicamentos.Add(medicamento);

            return codigo;
        }

        public void AlterarPreco(long codigo, double preco)
        {
            var medicamento = medicamentos.FirstOrDefault(m => m.Codigo == codigo);

            if (medicamento != null)
            {
                medicamento.Preco = preco;
            }
            else
            {
                Console.WriteLine("Medicamento não encontrado");
            }
        }

        public void ImprimirMedicamento(long codigo)
        {
            var medicamento = medicamentos.FirstOrDefault(m => m.Codigo == codigo);

            if (medicamento != null)
            {
                medicamento.Imprimir();
            }
            else
            {
               Console.WriteLine("Medicamento não encontrado");
            }
        }

        public long BuscarCodigoPorNome(string nome)
        {
            var medicamento = medicamentos.FirstOrDefault(m => m.Nome == nome);

            if (medicamento != null)
            {
                return medicamento.Codigo;
            }

            return 0;
        }

        public void ImprimirMedicamentosPorTipo(TipoMedicamento tipo)
        {
            var medicamentosPorTipo = medicamentos.Where(m => m.Tipo == tipo);

            if (medicamentosPorTipo.Any()) {

                foreach (var medicamento in medicamentosPorTipo)
                {
                    medicamento.Imprimir();
                }
            }

            else
                {
                    Console.WriteLine($"Não Há medicamentos cadastrados do tipo {tipo}.");
                }
        }
    }
}



