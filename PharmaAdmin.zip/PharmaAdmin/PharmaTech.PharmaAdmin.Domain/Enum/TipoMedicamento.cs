﻿

namespace PharmaAdminDomain.Enum
{


    public enum TipoMedicamento
    {
        Original = 1,
        Generico = 2,
        Similar = 3
    }
}
    


